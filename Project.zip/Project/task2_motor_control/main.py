from motor_controller import MotorController
from time import sleep

motor_controller = MotorController()

motor_controller.start_motor()
