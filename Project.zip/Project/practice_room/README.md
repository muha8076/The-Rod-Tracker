# Practice Room

Use this folder to commit the things that try out. For instance, a script to print a "Hello World" using Python or the scripts you write while following the recommended tutorials.